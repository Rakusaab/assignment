<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SendFeedBackController extends Controller
{
    function index() {

    	return view('sendfeedback');

    }
}
