
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Game login</title>
    <link rel="stylesheet" href="../php-3/temple.css">
</head>
<body>
<div class="ful-container">
<img src="..//php-3/template image gorila.png" alt="photo">
    <div class="container">
        <div class="welcome">
           
        <h1>Welcome to Temple run login</h1>
    </div>

      
    <form action="index.php" method="post">
        <input type="text" name="name" id="name" placeholder="Enter your name">
       
        <input type="email" name="email" id="email" placeholder="Enter your email">
        <input type="password" name="password" id="password" placeholder="Enter your password">
       
        <button class="btn"> submit </button>
        <!-- <button class="btn"> Reset </button> -->
    </form>
    </div>
</div>
</body>
</html>

<?php
if(isset($_POST['name'])){
$server = "localhost";
$username = "root";
$password = "";
$con = mysqli_connect($server, $username, $password);
if(!$con){
    die("connection to this database failed due to" .mysqli_connect_error());
}
//echo "success connecteing to the db";

$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];


$sql ="INSERT INTO `game` . `game` ( `name`, `email`, `password`, `dt`) VALUES ( '$name', '$email', '$password', '2021-05-13 12:09:45.000000');";
//echo $sql;
if($con->query($sql) == true){
    //echo "successfully inserted";
}
else{
    echo "ERROR: $sql <br> $con->error";
}
 $con->close();
}

?>

